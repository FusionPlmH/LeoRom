MODDIR=${0%/*}
resetprop --delete ro.config.iccc_version